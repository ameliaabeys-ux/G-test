package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import com.example.R
import com.example.util.rememberSubtleHaptics

// Fixed-width slots keep the Row layout stable while only the selected capsule is animated.
data class NavItem(@DrawableRes val iconRes: Int, val label: String)

val navItems = listOf(
    NavItem(R.drawable.character, "Characters"),
    NavItem(R.drawable.weapon, "Weapons"),
    NavItem(R.drawable.artifact, "Artifacts"),
    NavItem(R.drawable.teams, "Teams"),
    NavItem(R.drawable.tierlist, "Tier List")
)

private val purpleGradient = Brush.linearGradient(
    colors = listOf(Color(0xFF8E2DE2), Color(0xFF6A11CB))
)

@Composable
fun FloatingBottomNavBar(
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 8.dp)
            .height(68.dp)
            .clip(RoundedCornerShape(34.dp))
            .background(Color(0xFF12141C))
            .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(34.dp)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                NavBarItem(item, index == selectedIndex) { onItemSelected(index) }
            }
        }
    }
}

@Composable
private fun RowScope.NavBarItem(
    item: NavItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val haptics = rememberSubtleHaptics()
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val iconAlpha by animateFloatAsStateCompat(if (isSelected) 1f else .70f)
        val pressScale = if (pressed) .96f else 1f

    // Fixed slot: changing the active item never re-measures or moves the other tabs.
    Box(
        modifier = Modifier
            .weight(1f)
            .height(56.dp)
            .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = Color.White.copy(alpha = .20f)),
                onClick = { haptics.performTabSelect(); onClick() }
            )
            .testTag("nav_tab_${item.label.lowercase().replace(" ", "_")}"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = if (isSelected) Modifier
                .clip(RoundedCornerShape(28.dp))
                .background(purpleGradient)
                .padding(horizontal = 10.dp, vertical = 8.dp)
            else Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(item.iconRes),
                contentDescription = item.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(26.dp).graphicsLayer { alpha = iconAlpha }
            )
            if (isSelected) {
                Spacer(Modifier.width(5.dp))
                Text(
                    text = item.label,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
private fun animateFloatAsStateCompat(target: Float): Float {
    val value by androidx.compose.animation.core.animateFloatAsState(
        targetValue = target,
        animationSpec = tween(140, easing = FastOutSlowInEasing),
        label = "nav_float"
    )
    return value
}
